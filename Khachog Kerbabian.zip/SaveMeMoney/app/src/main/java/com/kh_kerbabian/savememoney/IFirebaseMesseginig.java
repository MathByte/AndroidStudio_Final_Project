package com.kh_kerbabian.savememoney;

public interface IFirebaseMesseginig {

    public void RunNotification();
}
